<?php
	namespace Controller;

	use \Psr\Http\Message\ServerRequestInterface as Request;
	use \Psr\Http\Message\ResponseInterface as Response;
	use Illuminate\Database\Capsule\Manager as DB;

	use Models\OrderServiceHistory;
	use Models\OrderServiceBarangHistory;
	use Models\Barang;
	use Models\SettingDayToko;
	use Models\SettingTimeToko;
	use Models\SettingPenjual;
	use Models\Toko;
	use Models\User;
	use Models\Orders;
	use Models\Tagihan;
	use Models\Etalase;
	use Models\TagihanHistory;
	use Models\TopupHistoryToko;
	use Models\TopupToko;
	use Models\SettingOngkirToko;
	use Models\TokoVsEkspedisi;
	use Models\Voucher;
	use Models\VoucherHistory;

	use Tools\Res;
	use Tools\Helper;
	use Tools\PushNotif;

	class BisnisController{

		protected $ci;
		public $setting;

		public function __construct(ContainerInterface $ci) {
			$this->ci = $ci;
			self::$setting = Settings::first();
		}

		public static function changeStatus(Request $req,Response $res){
			$p = $req->getParsedBody();
			$id = $req->getAttribute('id');
			$status = $req->getAttribute('status');

      $m = OrderServiceHistory::where("id",$id)->first();
      $b = OrderServiceBarangHistory::where("order_service_history_id",$m['id'])->first();
      $t = Toko::where("id",$b['toko_id'])->first();
      if($t['services_id'] == "1") $orderTypeId = "6";
      else $orderTypeId = "4";

			if( $status == "Success" ){
          $message = "Pesanan Anda telah berhasil di kirim";
          $isChange = true;
          $m->status = "Success";
      }else  if( $status == "Progress" ){
          $message = "Pesanan Sedang di siapkan / proses kirim";
          $isChange = true;
          $m->status = "Progress";
      }else{
          $message = "Pesanan Anda gagal di kirim";
          $isChange = true;
          $m->status = "Cancel";
          $m->alasan = $p["alasan"];
      }

      $dataPush = [
				"action" => "update_status_order_barang",
				"history_id" => $id,
				"intent" => "move"
			];

      $user = User::where("id",$m['user_id'])->first();
    	$push = PushNotif::pushTo($message,"Klik untuk detail",$user['firebase_token'],$dataPush);

    		    if( $m->save() ){

								//jika pesanan batal, maka kembalikan sharing profit
								if( $m->status == "Cancel" ){
										$mToko = Toko::where("id",$b['toko_id'])->first();
										$besarBagiHasil = $mToko['nominal_bagi_hasil'];
										$tipeBagihasil = $mToko['tipe_bagi_hasil'];
										$tipeBagihasilAmount = $mToko['tipe_bagi_hasil_amount'];

										if( $tipeBagihasil=="Prosentase" ){
											$ambil = ($m->price * $besarBagiHasil)/100;
											$historySaldo = new TopupHistoryToko;
											$historySaldo->nominal = $ambil;
											$historySaldo->toko_id = $b['toko_id'];
											$historySaldo->status = "Success";
											$historySaldo->type = "tambah";
											$historySaldo->deskripsi = "Pengembalian deposit transaksi (bagi hasil) karena transaksi di batalkan oleh user, no. transaksi #" . $m->id;
											$historySaldo->save();

											//update toko
											$topupToko = TopupToko::where("toko_id",$b['toko_id'])->first();
											$topupToko->nominal += $ambil;
											$topupToko->save();
										}
								}

    		        //update eo_ordes
    		        $o = Orders::where("order_id",$id)->where("order_type_id",$orderTypeId)->first();
    		        if( $m['status'] == "Success"  ||  $m['status'] == "Complete" ){
    		            $o['status'] = "Complete";
    		            //jika complete dan pakai saldo
    		            if($m['order_method'] == 'Saldo'){

    		                //insert into tagihan
    		                $tagihan = Tagihan::where('toko_id',$b['toko_id'])->first();
    	                    if( !isset($tagihan['toko_id']) ){
    	                        $tagihan = new Tagihan;
    	                        $tagihan->nominal = 0;
    	                    }

    	                    $tagihan->toko_id = $b['toko_id'];
    	                    $tagihan->nominal += $m['price'];
    	                    if(!$tagihan->save()){
    	                        return Res::cb($res,false,"Gagal 4");
    	                    }


    	                    $tagihanH = new TagihanHistory;
    		                $tagihanH->nominal = $m['price'];
    		                $tagihanH->created_at = date('Y-m-d H:i:s');
    		                $tagihanH->updated_at = date('Y-m-d H:i:s');
    		                $tagihanH->tagihan_id = $tagihan->id;
    		                $tagihanH->order_id = $m->id;
    		                if(!$tagihanH->save()){
    	                       	return Res::cb($res,false,"Gagal 3");
    	                    }else{
    	                    	$o->save();
    	                    	return Res::cb($res,true,"Ubah status berhasil");
    	                    }

    		            }
    		        }else if( $m['status'] == "Progress" ){
    		            $o['status'] = "Progress";
    		        }else{
    		             $o['status'] = "Cancel";
    		        }

    		        if(!$o->save()){
    		            return Res::cb($res,false,"Gagal Mengubah Status, kode : 101");
    		        }else
    		             return Res::cb($res,true,"Berhasil");
                }else{
                    return Res::cb($res,false,"Gagal Mengubah Status, kode : 102");
                }

		}

		public static function getDashboard(Request $req,Response $res){
			$tokoId = $req->getAttribute("toko_id");

			//total produk
			$tp = Barang::where("toko_id",$tokoId)->get();

			//total produk terjual
			$tpj = 0;
			$q0 = DB::Select("select qty from eo_order_service_barang_history h
							inner join eo_order_service_history sh on sh.id = h.order_service_history_id
							and (sh.status = 'Complete' or sh.status = 'Success')

							where h.toko_id = ".$tokoId."
			 ");
			foreach( $q0 as $v ){
				$tpj += (int) $v->qty;
			}

			//total produk terjual bulan
			$bln = date('Y-m');
			$tptb = 0;
			$q = DB::Select("select qty from eo_order_service_barang_history h
							inner join eo_order_service_history sh on sh.id = h.order_service_history_id
								and (sh.status = 'Complete' or sh.status = 'Success')

							where h.toko_id = ".$tokoId."
			 				and date_format(sh.created_at,'%Y-%m') = '".$bln."'

			 ");



			 foreach( $q as $v ){
				$tptb += (int) $v->qty;
			}

			 //total produk terjual hari
			$hari = date('Y-m-d');
			$tpth = 0;
			$q1 = DB::Select("select qty from eo_order_service_barang_history h
							inner join eo_order_service_history sh on sh.id = h.order_service_history_id
							and (sh.status = 'Complete' or sh.status = 'Success')

							where h.toko_id = ".$tokoId."
			 				and date_format(sh.created_at,'%Y-%m-%d') = '".$hari."'
			 ");



			 foreach( $q1 as $v ){
				$tpth += (int) $v->qty;
			}

			return Res::cb($res,true,"Berhasil",
				[
					"total_produk" => count($tp),
					"total_produk_terjual" => $tpj,
					"terjual_bulan" => $tptb,
					"terjual_hari" => $tpth
				]
			);

		}

		public static function getOrderByStatus(Request $req,Response $res) {
			$status = $req->getAttribute("status");
			$tokoId = $req->getAttribute("toko_id");

			$orders = DB::select("select h.*,u.nama as nama_user, date_format(h.created_at,'%H:%i:%s') as time,
			date_format(h.created_at,'%Y-%m-%d') as tgl, 'Belanja' as type
			from eo_order_service_history h
			inner join eo_order_service_barang_history b on b.toko_id = $tokoId
				and b.order_service_history_id = h.id
			inner join eo_user u on u.id = h.user_id
			where h.status = '".$status."' group by b.order_service_history_id order by b.created_at desc");

			return Res::cb($res,true,"Berhasil",["orders" => $orders]);

		}

		public static function getEtalase(Request $req,Response $res){
			$id = $req->getAttribute("toko_id");
			$e = Etalase::where("toko_id",$id)->get();
			return Res::cb($res,true,"Berhasil",["etalase" => $e]);
		}

		public static function updateEtalase(Request $req,Response $res){
			$p = $req->getParsedBody();
			if(isset($p['id']))
				$e = Etalase::where("id",$p['id'])->first();
			else
				$e = new Etalase;

			$e->nama = $p['nama'];
			$e->visible = $p['visible'];
			$e->toko_id = $p['toko_id'];
			if( $e->save() ){
					return Res::cb($res,true,"Berhasil");
			}else{
				return Res::cb($res,false,"Berhasil");
			}

		}

		public static function getVoucher(Request $req,Response $res){
			$id = $req->getAttribute("toko_id");
      $m = DB::select("select v.*,
        v.max_penggunaan - 
        (select count(1) from eo_voucher_history h 
                  where h.toko_id = v.toko_id and v.kode = h.voucher_kode and h.toko_id = $id and h.status = 'Success' ) as sisa
        from eo_voucher v where v.toko_id =  " . $id);
			return Res::cb($res,true,"Berhasil",["voucher" => $m]);
		}

		public static function getHistoryVoucher(Request $req,Response $res){
			$id = $req->getAttribute("toko_id");
			$m = DB::select("select h.*,u.nama as nama_user 
                      from eo_voucher_history h 
                      inner join eo_user u on u.id = h.user_id where h.toko_id = " . $id);
			return Res::cb($res,true,"Berhasil",["history" => $m]);
		}

		public static function updateVoucher(Request $req,Response $res){
			$p = $req->getParsedBody();
			if($p['id'] != "0")
				$e = Voucher::where("id",$p['id'])->first();
			else{
        //cek jika ada okde yang sama
        $v = Voucher::where("kode",$p['kode'])->where("toko_id",$p['toko_id'])->first();
        if( !is_null($v) ) return Res::cb($res,false,"Kode tidak boleh sama"); 
        $e = new Voucher;
      }

			$e->kode = $p['kode'];
			$e->max_per_user = $p['max_per_user'];
			$e->max_penggunaan = $p['max_penggunaan'];
			$e->tipe = $p['tipe'];
			$e->nominal = $p['nominal'];
      $e->toko_id = $p['toko_id'];
			if( $e->save() ){
					return Res::cb($res,true,"Berhasil");
			}else{
				return Res::cb($res,false,"Berhasil");
			}

		}

		public static function getReport(Request $req,Response $res) {
			$tokoId = $req->getAttribute("toko_id");
			$post = $req->getParsedBody();
			$dateFrom = $post['date_from'];  //yyyy-mm-dd
			$dateTo = $post['date_to'];		//yyyy-mm-dd

			$orders = DB::select("select h.*,u.nama as nama_user,date_format(h.created_at,'%H:%i:%s') as time,
			date_format(h.created_at,'%Y-%m-%d') as tgl, 'Belanja' as type
			from eo_order_service_history h
			inner join eo_order_service_barang_history b on b.toko_id = $tokoId
				and b.order_service_history_id = h.id
			inner join eo_user u on u.id = h.user_id
			where h.status IN ('Success','Complete')
				and date_format(h.created_at,'%Y-%m-%d') between '".$dateFrom."' and '".$dateTo."'
			group by b.order_service_history_id");

			return Res::cb($res,true,"Berhasil",["orders" => $orders]);

		}

		public static function getSetting(Request $req,Response $res) {
			$tokoId = $req->getAttribute("toko_id");
			$day = 	DB::select("select * from eo_setting_day_toko p
								where p.toko_id = $tokoId");

			$time = 	DB::select("select * from eo_setting_time_toko p
								where p.toko_id = $tokoId");

			$tk = Toko::where("id",$tokoId)->first();
			$ret = ["day" => $day[0],"time"=>$time];
			$ret['toko'] = $tk;
			$ret['setting_toko'] = SettingPenjual::where("toko_id",$tokoId)->first();
			$ret['ongkir'] = SettingOngkirToko::where("toko_id",$tokoId)->first();

			return Res::cb($res,true,"Berhasil",$ret);
		}

		public static function updateSettingEkspedisi(Request $req,Response $res){
		   $tokoId = $req->getAttribute("toko_id");
		   $eksId = $req->getAttribute("ekspedisi_id");
		   $visible = $req->getAttribute("visible");
		   $m = TokoVsEkspedisi::where("ekspedisi_id",$eksId)->where("toko_id",$tokoId)->first();
		   if( is_null($m) ){
		       $m = new TokoVsEkspedisi;
		       $m->toko_id = $tokoId;
		       $m->ekspedisi_id = $eksId;
		       $m->visible = $visible;
		   }else{
		       $m->visible = $visible;
		   }

		   if($m->save()){
		       return Res::cb($res,true,"Berhasil");
		   }else{
		       return Res::cb($res,false,"Kesalahan server, hub. Admin");
		   }

		}

		public static function getHistoryTopup(Request $req,Response $res){
		   $tokoId = $req->getAttribute("toko_id");
		   $m = DB::select("select * from eo_topup_history_toko where toko_id = " . $tokoId . " and created_at like '%".date('Y-m-d')."%' order by created_at desc");
		   return Res::cb($res,true,"Berhasil",["history"=>$m]);
		}

		public static function getEkspedisi(Request $req,Response $res){
		   $tokoId = $req->getAttribute("toko_id");
		   $m = DB::select("select e.*,
		   case when e.id is not null then t.visible else 'no' end as visible
		   from eo_ekspedisi e
		   left join eo_toko_vs_ekspedisi t on t.ekspedisi_id = e.id and  t.toko_id = " . $tokoId . " and e.visible='yes'
		   where e.id != 1");
		   return Res::cb($res,true,"Berhasil",["ekspedisi"=>$m]);
		}

		public static function updateSetting(Request $req,Response $res) {
			$tokoId = $req->getAttribute("toko_id");
			$p = $req->getParsedBody();
			//return Res::cb($res,false,json_encode($p),$p);
			//var_dump($p);die();

            $ongkir = SettingOngkirToko::where("toko_id",$tokoId)->first();
            $ongkir->tipe = $p['tipe'];
            $ongkir->is_active = $p['is_active'];
            $ongkir->km_pertama = $p['km_pertama'];
            $ongkir->harga_km_pertama = $p['harga_km_pertama'];
            $ongkir->harga_km_selanjutnya = $p['harga_km_selanjutnya'];
            $ongkir->harga_per_kg = $p['harga_per_kg'];
            $ongkir->save();


            $set = SettingPenjual::where("toko_id",$tokoId)->first();
            $set->master_deskripsi = $p['master_deksripsi'];
            $set->master_deskripsi_pengiriman = $p['master_deksripsi_pengiriman'];
            $set->save();

			$sp = SettingDayToko::where("toko_id",$tokoId)->first();
			$sp['h_senin'] 	= $p['senin'];
			$sp['h_selasa'] = $p['selasa'];
			$sp['h_rabu'] 	= $p['rabu'];
			$sp['h_kamis'] 	= $p['kamis'];
			$sp['h_jumat'] 	= $p['jumat'];
			$sp['h_sabtu'] 	= $p['sabtu'];
			$sp['h_ahad'] 	= $p['minggu'];
			$sp->save();


			//simpan time
			$st = SettingTimeToko::where("toko_id",$tokoId)->where("setting_day_id","1")->first();
			$st->waktu_mulai = $p['senin_buka'];
			$st->waktu_akhir = $p['senin_tutup'];
			$st->save();

			$st = SettingTimeToko::where("toko_id",$tokoId)->where("setting_day_id","2")->first();
			$st->waktu_mulai = $p['selasa_buka'];
			$st->waktu_akhir = $p['selasa_tutup'];
			$st->save();

			$st = SettingTimeToko::where("toko_id",$tokoId)->where("setting_day_id","3")->first();
			$st->waktu_mulai = $p['rabu_buka'];
			$st->waktu_akhir = $p['rabu_tutup'];
			$st->save();

			$st = SettingTimeToko::where("toko_id",$tokoId)->where("setting_day_id","4")->first();
			$st->waktu_mulai = $p['kamis_buka'];
			$st->waktu_akhir = $p['kamis_tutup'];
			$st->save();

			$st = SettingTimeToko::where("toko_id",$tokoId)->where("setting_day_id","5")->first();
			$st->waktu_mulai = $p['jumat_buka'];
			$st->waktu_akhir = $p['jumat_tutup'];
			$st->save();

			$st = SettingTimeToko::where("toko_id",$tokoId)->where("setting_day_id","6")->first();
			$st->waktu_mulai = $p['sabtu_buka'];
			$st->waktu_akhir = $p['sabtu_tutup'];
			$st->save();

			$st = SettingTimeToko::where("toko_id",$tokoId)->where("setting_day_id","7")->first();
			$st->waktu_mulai = $p['minggu_buka'];
			$st->waktu_akhir = $p['minggu_tutup'];
			$st->save();

			return Res::cb($res,true,"Berhasil");

		}

	}
?>
