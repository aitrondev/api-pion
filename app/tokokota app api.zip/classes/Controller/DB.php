<?php
    /**
     * 
     */
    class DB
    {
    }
    
?>