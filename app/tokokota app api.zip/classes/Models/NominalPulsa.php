<?php

namespace Models;

class NominalPulsa extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'at_nominal_pulsa';

}