<?php

namespace Models;

class VVendor extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'v_vendor';
}