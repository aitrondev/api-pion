<?php

namespace Models;

class VoucherHistory extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_voucher_history';
}
