<?php

namespace Models;

class PijatType extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_pijat';

}