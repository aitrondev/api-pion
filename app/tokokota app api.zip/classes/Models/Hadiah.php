<?php

namespace Models;

class Hadiah extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_hadiah';
}
