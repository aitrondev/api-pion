<?php

namespace Models;

class TopupVendor extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_topup_vendor';

}