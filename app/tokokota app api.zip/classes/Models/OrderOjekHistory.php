<?php
	
	namespace Models;
	
	class OrderOjekHistory extends \Illuminate\Database\Eloquent\Model
	{
		protected $table = "eo_order_ojek_history";
	}