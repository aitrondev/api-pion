<?php

namespace Models;

class TopupToko extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_topup_toko';
}
