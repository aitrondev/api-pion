<?php
    namespace Models;
	class TagihanHistory extends \Illuminate\Database\Eloquent\Model
	{
		protected $table = 'eo_tagihan_history';
	}
?>