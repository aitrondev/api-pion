<?php

namespace Models;

class Settings extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_setting';
	
}