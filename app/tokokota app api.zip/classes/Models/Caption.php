<?php

namespace Models;

class Caption extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'b_captions';
}
