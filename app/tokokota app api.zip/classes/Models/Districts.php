<?php

namespace Models;

class Districts extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'districts';

}