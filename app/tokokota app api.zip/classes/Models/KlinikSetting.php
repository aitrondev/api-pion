<?php

namespace Models;

class KlinikSetting extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'bx_klinik_setting';
}