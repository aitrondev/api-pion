<?php

namespace Models;

class MLog extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'bx_log';

}