<?php

namespace Models;

class OrderJasaHistory extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_order_jasa_history';

}