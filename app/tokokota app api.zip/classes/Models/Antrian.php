<?php

namespace Models;

class Antrian extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'bx_antrian';

	
}