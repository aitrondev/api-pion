<?php



namespace Models;



class User extends \Illuminate\Database\Eloquent\Model

{

	protected $table = 'v_user';

}