<?php

namespace Models;

class OrderServiceBarangHistory extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_order_service_barang_history';

}