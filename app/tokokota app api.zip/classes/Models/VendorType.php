<?php
namespace Models;

class VendorType extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_vendor_type';
}