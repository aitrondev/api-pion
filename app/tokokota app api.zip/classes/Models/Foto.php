<?php

namespace Models;

class Foto extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_foto';

}