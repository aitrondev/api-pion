<?php

namespace Models;

class SettingDayToko extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_setting_day_toko';
}