<?php

namespace Models;

class CreditSetting extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_credit_setting';

}