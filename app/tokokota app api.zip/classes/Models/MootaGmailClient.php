<?php

namespace Models;

class MootaGmailClient extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_moota_gmail_client';
}