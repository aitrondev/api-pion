<?php

namespace Models;

class TokoVsEkspedisi extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_toko_vs_ekspedisi';
}
