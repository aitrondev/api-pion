<?php

namespace Models;

class Jasa extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_jasa';

}