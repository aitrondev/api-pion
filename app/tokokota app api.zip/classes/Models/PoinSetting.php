<?php

namespace Models;

class PoinSetting extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_setting_poin';
}
