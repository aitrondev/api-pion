<?php

namespace Models;

class FBAuthResponse extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'b_fb_auth_response';
}