<?php

namespace Models;

class OrderCourierHistory extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_order_courier_history';

}