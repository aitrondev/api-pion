<?php

namespace Models;

class MootaForgotpassHistory extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'moota_forgotpass_history';
}
