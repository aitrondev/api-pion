<?php

namespace Models;

class Etalase extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_etalase';
}
