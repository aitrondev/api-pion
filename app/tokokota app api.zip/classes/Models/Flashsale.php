<?php

namespace Models;

class Flashsale extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_flashsale';
}
