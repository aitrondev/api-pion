<?php

namespace Models;

class PUserRole extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'p_user_role';

}