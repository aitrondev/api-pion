<?php

namespace Models;

class SuspendHistory extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'at_suspend_history';
	
}