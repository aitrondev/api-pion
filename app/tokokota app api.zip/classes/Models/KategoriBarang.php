<?php

namespace Models;

class KategoriBarang extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_kategori_barang';

}