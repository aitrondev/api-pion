<?php

namespace Models;

class PesertaVsProgramPendidikan extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'h_peserta_vs_program_pendidikan';
}
