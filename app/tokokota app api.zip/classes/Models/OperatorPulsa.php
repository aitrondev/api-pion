<?php

namespace Models;

class OperatorPulsa extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'at_operator_pulsa';

}