<?php

namespace Models;

class Rate extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'v_rate';

}