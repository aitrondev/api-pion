<?php

namespace Models;

class VendorPosition extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_vendor_position';

}