<?php

namespace Models;

class ChatConst extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_chats_const';
}