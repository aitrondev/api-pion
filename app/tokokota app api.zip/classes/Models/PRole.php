<?php

namespace Models;

class PRole extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'p_role';

}