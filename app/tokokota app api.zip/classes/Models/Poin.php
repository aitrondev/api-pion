<?php

namespace Models;

class Poin extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_poin';
}
