<?php

namespace Models;

class LaundrySatuan extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_laundry_satuan';
}
