<?php

namespace Models;

class Faq extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_faq';

}