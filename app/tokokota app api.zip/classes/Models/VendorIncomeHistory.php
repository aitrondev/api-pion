<?php



namespace Models;



class VendorIncomeHistory extends \Illuminate\Database\Eloquent\Model

{

	protected $table = 'eo_vendor_income_history';

}