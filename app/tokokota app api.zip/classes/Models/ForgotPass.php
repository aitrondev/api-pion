<?php

namespace Models;

class ForgotPass extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_forgot_pass';
}