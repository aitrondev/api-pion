<?php

namespace Models;

class RateHistory extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_rate_history';

}