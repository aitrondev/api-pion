<?php

namespace Models;

class Services extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'at_services';

}