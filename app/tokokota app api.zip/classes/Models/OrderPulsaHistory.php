<?php

namespace Models;

class OrderPulsaHistory extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'at_order_pulsa_history';

}