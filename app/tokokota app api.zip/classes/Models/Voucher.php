<?php

namespace Models;

class Voucher extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_voucher';
}
