<?php

namespace Models;

class LaundryItemsHistory extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_order_laundry_items_history';
}
