<?php

namespace Models;

class Scheduler extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'b_scheduler';
}
