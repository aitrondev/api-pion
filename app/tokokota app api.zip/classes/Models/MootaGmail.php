<?php

namespace Models;

class MootaGmail extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'moota_gmail';
}
