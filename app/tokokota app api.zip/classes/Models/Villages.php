<?php

namespace Models;

class Villages extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'villages';
}