<?php
	class VBlog
	{
		protected $table = "v_blog";
	}
?>