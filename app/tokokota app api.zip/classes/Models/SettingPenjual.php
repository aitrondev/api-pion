<?php

namespace Models;

class SettingPenjual extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_setting_penjual';

}