<?php

namespace Models;

class Slider extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_slider';
	
}