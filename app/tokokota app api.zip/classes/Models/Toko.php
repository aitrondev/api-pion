<?php

namespace Models;

class Toko extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_toko';

}