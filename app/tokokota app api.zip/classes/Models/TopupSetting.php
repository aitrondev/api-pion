<?php

namespace Models;

class TopupSetting extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_topup_setting';
}