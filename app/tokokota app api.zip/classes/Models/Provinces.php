<?php

namespace Models;

class Provinces extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'provinces';

}