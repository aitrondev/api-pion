<?php

namespace Models;

class PUser extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'p_user';

}