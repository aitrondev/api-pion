<?php

namespace Models;

class TopupHistoryToko extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_topup_history_toko';
}
