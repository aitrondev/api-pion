<?php

namespace Models;

class OrderJasaItemsHistory extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_order_jasa_items_history';
}
