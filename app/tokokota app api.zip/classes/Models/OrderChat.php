<?php

namespace Models;

class OrderChat extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_order_chat';
}