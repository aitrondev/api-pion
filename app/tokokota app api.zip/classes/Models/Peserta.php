<?php

namespace Models;

class Peserta extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'h_peserta';
}
