<?php

namespace Models;

class OrderLaundryHistory extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_order_laundry_history';

}