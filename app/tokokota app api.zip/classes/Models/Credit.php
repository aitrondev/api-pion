<?php

namespace Models;

class Credit extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_credit';

}