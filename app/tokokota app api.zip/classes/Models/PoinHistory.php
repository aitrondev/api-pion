<?php

namespace Models;

class PoinHistory extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_poin_history';

}
