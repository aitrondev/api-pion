<?php

namespace Models;

class TypeLaundry extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_type_laundry';

}