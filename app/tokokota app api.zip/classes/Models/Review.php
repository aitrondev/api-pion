<?php

namespace Models;

class Review extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'v_review';

}