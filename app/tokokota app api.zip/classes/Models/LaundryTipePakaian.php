<?php

namespace Models;

class LaundryTipePakaian extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_tipe_pakaian_laundry';
}