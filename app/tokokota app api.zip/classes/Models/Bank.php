<?php

namespace Models;

class Bank extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_bank';

	
}