<?php

namespace Models;

class FotoBarang extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_foto_barang';

}