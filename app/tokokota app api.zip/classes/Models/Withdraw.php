<?php

namespace Models;

class Withdraw extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_withdraw';
}