<?php

namespace Models;

class Admin extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_admin';
}