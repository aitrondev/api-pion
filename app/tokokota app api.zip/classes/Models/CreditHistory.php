<?php

namespace Models;

class CreditHistory extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_credit_history';

}