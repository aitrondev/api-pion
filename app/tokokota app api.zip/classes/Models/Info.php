<?php

namespace Models;

class Info extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_info';

}