<?php

namespace Models;

class LaundryTipeCuci extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_tipe_cuci';
}