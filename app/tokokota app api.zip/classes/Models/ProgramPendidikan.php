<?php

namespace Models;

class ProgramPendidikan extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'h_program_pendidikan';

}