<?php

namespace Models;

class InstaAuthResponse extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'b_insta_auth_response';
}