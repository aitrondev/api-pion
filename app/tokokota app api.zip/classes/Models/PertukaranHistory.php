<?php

namespace Models;

class PertukaranHistory extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_penukaran_history';
}
