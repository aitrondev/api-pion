<?php

namespace Models;

class Chat extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_chats';
}