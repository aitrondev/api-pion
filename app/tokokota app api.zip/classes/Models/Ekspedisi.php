<?php

namespace Models;

class Ekspedisi extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_ekspedisi';
}
