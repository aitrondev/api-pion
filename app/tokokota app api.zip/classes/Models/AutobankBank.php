<?php

namespace Models;

class AutobankBank extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'autobank_bank';
}
