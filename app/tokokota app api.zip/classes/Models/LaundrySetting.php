<?php

namespace Models;

class LaundrySetting extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_laundry_setting';
}
