<?php

namespace Models;

class PijatDuration extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_pijat_durasi';
}