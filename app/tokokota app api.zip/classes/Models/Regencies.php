<?php

namespace Models;

class Regencies extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'regencies';

}