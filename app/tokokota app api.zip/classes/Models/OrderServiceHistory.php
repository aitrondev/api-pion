<?php

namespace Models;

class OrderServiceHistory extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_order_service_history';

}