<?php

namespace Models;

class Transaksi extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'b_transaksi';
}
