<?php

namespace Models;

class Orders extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_orders';

}