<?php

namespace Models;

class OrderTypeLaundryHistory extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'at_order_type_laundry_history';

}