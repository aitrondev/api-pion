<?php



namespace Models;



class Vendor extends \Illuminate\Database\Eloquent\Model

{

	protected $table = 'eo_vendor';

}