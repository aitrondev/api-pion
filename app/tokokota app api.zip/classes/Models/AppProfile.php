<?php

namespace Models;

class AppProfile extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_app';
}