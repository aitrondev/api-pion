<?php

namespace Models;

class Lpk extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'h_lpk';

}