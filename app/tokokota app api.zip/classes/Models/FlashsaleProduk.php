<?php

namespace Models;

class FlashsaleProduk extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_flashsale_produk';
}
