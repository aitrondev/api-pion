<?php
    namespace Models;
    
	class InputUser extends \Illuminate\Database\Eloquent\Model
	{
		protected $table = "eo_user";
	}
?>