<?php

namespace Models;

class PijatSetting extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_pijat_setting';

}