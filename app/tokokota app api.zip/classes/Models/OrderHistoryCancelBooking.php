<?php



namespace Models;



class OrderHistoryCancelBooking extends \Illuminate\Database\Eloquent\Model

{

	protected $table = 'eo_order_history_cancel_booking';

}