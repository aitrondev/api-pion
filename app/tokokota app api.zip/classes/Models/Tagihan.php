<?php
    namespace Models;
	class Tagihan extends \Illuminate\Database\Eloquent\Model
	{
		protected $table = 'eo_tagihan';
	}
?>