<?php

namespace Models;

class Pasar extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_pasar';
}
