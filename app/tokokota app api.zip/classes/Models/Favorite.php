<?php

namespace Models;

class Favorite extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_favorite';
}
