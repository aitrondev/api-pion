<?php

namespace Models;

class KategoriToko extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_services';

	
}