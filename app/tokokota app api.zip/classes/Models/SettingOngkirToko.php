<?php

namespace Models;

class SettingOngkirToko extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_ekspedisi_antar_sendiri';

}