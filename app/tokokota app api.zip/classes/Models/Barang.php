<?php

namespace Models;

class Barang extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_barang';

}