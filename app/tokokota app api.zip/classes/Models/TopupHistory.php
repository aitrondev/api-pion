<?php

namespace Models;

class TopupHistory extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_topup_history';

}