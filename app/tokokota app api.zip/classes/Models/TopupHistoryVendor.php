<?php

namespace Models;

class TopupHistoryVendor extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_topup_history_vendor';

}