<?php

namespace Models;

class LaundryTipe extends \Illuminate\Database\Eloquent\Model
{
	protected $table = 'eo_tipe_laundry';
}