<?php 
	/**
	* 
	*/
	class MootaURL
	{
		
		public static $BASE_URL_APP = "https://app.moota.co/"; 
		public static $FORGOT_PASS = "https://app.moota.co/" . "password/reset"; 
	}
 ?>