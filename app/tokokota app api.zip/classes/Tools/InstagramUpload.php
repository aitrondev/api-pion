<?php
namespace Tools;

class InstagramUpload{
private $username;
private $password;
private $csrftoken;
private $phone_id;
private $guid;
private $uid;
private $device_id;
private $cookies;
private $api_url = 'https://i.instagram.com/api/v1';
private $ig_sig_key = '5ad7d6f013666cc93c88fc8af940348bd067b68f0dce3c85122a923f4f74b251';
private $sig_key_version = '4';
private $x_ig_capabilities = '3ToAAA==';
private $android_version = 18;
private $android_release = '4.3';
private $android_manufacturer = "Huawei";
private $android_model = "EVA-L19";
private $headers = array();
private $user_agent = "Instagram 10.3.2 Android (18/4.3; 320dpi; 720x1280; Huawei; HWEVA; EVA-L19; qcom; en_US)";

public function __construct(){
  $this->guid = $this->generateUUID();
  $this->phone_id = $this->generateUUID();
  $this->device_id = $this->generateDeviceId();
  $this->upload_id = $this->generateUploadId();
  $this->headers[] = "X-IG-Capabilities: ".$this->x_ig_capabilities;
  $this->headers[] = "X-IG-Connection-Type: WIFI";
}
public function Login($username="", $password=""){
  $this->username = $username;
  $this->password = $password;
  $this->csrftoken = $this->GetToken();
  $arrUidAndCooike = $this->GetLoginUidAndCookie();
  $this->uid = $arrUidAndCooike[0];
  $this->cookies = $arrUidAndCooike[1];
}
public function UploadPhoto($image, $caption){
  $image = "https://images.pexels.com/photos/67636/rose-blue-flower-rose-blooms-67636.jpeg";
  $this->UploadPhotoApi($image);
  $this->ConfigPhotoApi($caption);
}
public function UploadVideo($video, $image, $caption){
  $this->UploadVideoApi($video,$caption);
}
private function GetToken(){
  $strUrl = $this->api_url."/si/fetch_headers/?challenge_type=signup";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL,$strUrl);
  curl_setopt($ch, CURLOPT_HEADER, true);
  curl_setopt($ch, CURLOPT_POST, false);
  curl_setopt($ch, CURLOPT_HTTPHEADER, $this->headers);
  curl_setopt($ch, CURLOPT_USERAGENT, $this->user_agent);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $result = curl_exec($ch);
  curl_close ($ch);
  preg_match_all("|csrftoken=(.*);|U",$result,$arrOut, PREG_PATTERN_ORDER);
  $csrftoken = $arrOut[1][0];
  if($csrftoken != ""){
    return $csrftoken;
  }else{
    print $result;
    exit;
  }
}
private function GetLoginUidAndCookie(){
  $arrPostData = array();
  $arrPostData['login_attempt_count'] = "0";
  $arrPostData['_csrftoken'] = $this->csrftoken;
  $arrPostData['phone_id'] = $this->phone_id;
  $arrPostData['guid'] = $this->guid;
  $arrPostData['device_id'] = $this->device_id;
  $arrPostData['username'] = $this->username;
  $arrPostData['password'] = $this->password;
  $strUrl = $this->api_url."/accounts/login/";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL,$strUrl);
  curl_setopt($ch, CURLOPT_HEADER, true);
  curl_setopt($ch, CURLOPT_POST, true);
  curl_setopt($ch, CURLOPT_HTTPHEADER, $this->headers);
  curl_setopt($ch, CURLOPT_USERAGENT, $this->user_agent);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $this->generateSignature(json_encode($arrPostData)));
  curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
  $result = curl_exec($ch);
  curl_close ($ch);
  list($header, $body) = explode("\r\n\r\n", $result, 2);
  preg_match_all('/^Set-Cookie:\s*([^;]*)/mi', $header, $matches);
  $cookies = implode(";", $matches[1]);
  $arrResult = json_decode($body, true);
  if($arrResult['status'] == "ok"){
    $uid = $arrResult['logged_in_user']['pk'];
    return array($uid, $cookies);
  }else{
    print $body;
    exit;
  }
}
private function UploadPhotoApi($file){
  //var_dump(curl_file_create($file));die();
  $arrPostData = array();
  $arrPostData['_uuid'] = $this->upload_id;
  $arrPostData['_csrftoken'] = $this->csrftoken;
  $arrPostData['upload_id'] = $this->upload_id;
  $arrPostData['image_compression'] = '{"lib_name":"jt","lib_version":"1.3.0","quality":"100"}';
  $arrPostData['photo'] = $file;
  $strUrl = $this->api_url."/upload/photo/";
  echo $strUrl;die();
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL,$strUrl);
  curl_setopt($ch, CURLOPT_HEADER, false);
  curl_setopt($ch, CURLOPT_POST, true);
  curl_setopt($ch, CURLOPT_HTTPHEADER, $this->headers);
  curl_setopt($ch, CURLOPT_USERAGENT, $this->user_agent);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $arrPostData);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
  curl_setopt($ch, CURLOPT_COOKIE, $this->cookies);
  curl_setopt($ch, CURLOPT_FAILONERROR, true); // Required for HTTP error codes to be reported via our call to curl_error($ch)
  $result = curl_exec($ch);
  echo curl_getinfo($ch) . '<br/>';
echo curl_errno($ch) . '<br/>';
echo curl_error($ch) . '<br/>';

  var_dump($result);die();
  $arrResult = json_decode($result, true);
  if($arrResult['status'] == "ok"){
    return true;
  }else{
    print $result;
    exit;
  }
}
private function UploadVideoApi($file,$caption){
    $file = "https://instagram.fsub1-1.fna.fbcdn.net/vp/e8b92bc028bcb3d3f1491150145e5a0b/5B864C1C/t50.2886-16/39483697_705594059810348_2988417950836326400_n.mp4";
    $arrPostData = array();
    $arrPostData['_uuid'] = $this->upload_id;
    $arrPostData['_csrftoken'] = $this->csrftoken;
    $arrPostData['upload_id'] = $this->upload_id;
    $arrPostData['media_type'] = '2';
    $strUrl = $this->api_url."/upload/video/";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL,$strUrl);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $this->headers);
    curl_setopt($ch, CURLOPT_USERAGENT, $this->user_agent);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $arrPostData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_COOKIE, $this->cookies);
    $result = curl_exec($ch);
    curl_close ($ch);
    $arrResult = json_decode($result, true);
    $uploadUrl = $arrResult['video_upload_urls'][3]['url'];
    $job = $arrResult['video_upload_urls'][3]['job'];
    $headers = $this->headers;
    $headers[] = "Session-ID: ".$this->upload_id;
    $headers[] = "job: ".$job;
    $headers[] = "Content-Disposition: attachment; filename=\"video.mp4\"";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL,$uploadUrl);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
    curl_setopt($ch, CURLOPT_USERAGENT, $this->user_agent);
    curl_setopt($ch, CURLOPT_POSTFIELDS, file_get_contents($file));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_COOKIE, $this->cookies);
    $result = curl_exec($ch);
    //var_dump($result);die();
    curl_close ($ch);
    if($arrResult['status'] == "ok"){
      $this->UploadPhotoApi("https://images.pexels.com/photos/67636/rose-blue-flower-rose-blooms-67636.jpeg");
      //$this->ConfigVideoApi($caption);
      //return true;
    }else{
      print $result;
      exit;
    }
}
private function ConfigPhotoApi($caption){
  $arrPostData = array();
  $arrPostData['media_folder'] = "Instagram";
  $arrPostData['source_type'] = "4";
  $arrPostData['filter_type'] = "0";
  $arrPostData['_csrftoken'] = $this->csrftoken;
  $arrPostData['_uid'] = $this->uid;
  $arrPostData['_uuid'] = $this->upload_id;
  $arrPostData['upload_id'] = $this->upload_id;
  $arrPostData['caption'] = $caption;
  $arrPostData['device']['manufacturer'] = $this->android_manufacturer;
  $arrPostData['device']['model'] = $this->android_model;
  $arrPostData['device']['android_version'] = $this->android_version;
  $arrPostData['device']['android_release'] = $this->android_release;
  $strUrl = $this->api_url."/media/configure/";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL,$strUrl);
  curl_setopt($ch, CURLOPT_HEADER, false);
  curl_setopt($ch, CURLOPT_POST, true);
  curl_setopt($ch, CURLOPT_HTTPHEADER, $this->headers);
  curl_setopt($ch, CURLOPT_USERAGENT, $this->user_agent);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $this->generateSignature(json_encode($arrPostData)));
  curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
  curl_setopt($ch, CURLOPT_COOKIE, $this->cookies);
  $result = curl_exec($ch);
  var_dump($result);die();
  curl_close ($ch);
  $arrResult = json_decode($result, true);
  if($arrResult['status'] == "ok"){
    return true;
  }else{
    print $result;
    exit;
  }
}
private function ConfigVideoApi($caption){
  $arrPostData = array();
  $arrPostData['source_type'] = "3";
  $arrPostData['filter_type'] = "0";
  $arrPostData['poster_frame_index'] = "0";
  $arrPostData['length'] = "0.00";
  $arrPostData['"length":0'] = '"length":0.00';
  $arrPostData['audio_muted'] = "false";
  $arrPostData['video_result'] = "deprecated";
  $arrPostData['_csrftoken'] = $this->csrftoken;
  $arrPostData['_uid'] = $this->uid;
  $arrPostData['_uuid'] = $this->upload_id;
  $arrPostData['upload_id'] = $this->upload_id;
  $arrPostData['caption'] = $caption;
  $arrPostData['device']['manufacturer'] = $this->android_manufacturer;
  $arrPostData['device']['model'] = $this->android_model;
  $arrPostData['device']['android_version'] = $this->android_version;
  $arrPostData['device']['android_release'] = $this->android_release;
  $strUrl = $this->api_url."/media/configure/?video=1";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL,$strUrl);
  curl_setopt($ch, CURLOPT_HEADER, false);
  curl_setopt($ch, CURLOPT_POST, true);
  curl_setopt($ch, CURLOPT_HTTPHEADER, $this->headers);
  curl_setopt($ch, CURLOPT_USERAGENT, $this->user_agent);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $this->generateSignature(json_encode($arrPostData)));
  curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
  curl_setopt($ch, CURLOPT_COOKIE, $this->cookies);
  $result = curl_exec($ch);
  var_dump($result);

  curl_close ($ch);
  $arrResult = json_decode($result, true);
  if($arrResult['status'] == "ok"){
    return true;
  }else{
    print $result;
    exit;
  }
}
private function generateUUID(){
  $uuid = sprintf(
      '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
      mt_rand(0, 0xffff),
      mt_rand(0, 0xffff),
      mt_rand(0, 0xffff),
      mt_rand(0, 0x0fff) | 0x4000,
      mt_rand(0, 0x3fff) | 0x8000,
      mt_rand(0, 0xffff),
      mt_rand(0, 0xffff),
      mt_rand(0, 0xffff)
  );
  return $uuid;
}
private function generateDeviceId(){
  return 'android-'.substr(md5(time()), 16);
}
private function generateSignature($data){
  $hash = hash_hmac('sha256', $data, $this->ig_sig_key);
  return 'ig_sig_key_version='.$this->sig_key_version.'&signed_body='.$hash.'.'.urlencode($data);
}
function generateUploadId(){
  return number_format(round(microtime(true) * 1000), 0, '', '');
}
}
?>
?>
